personalInformation = {
    name: 'Nurullah',
    surname: 'KAZAN',
    location: {
        town: 'Samsun',
        adress: 'Soğuksu neighbourhood Gür street 10/3'
    },
    singular: {
        age: '23',
        placeOfBirth: 'Samsun/Çarşamba',
        favoriteFood: 'İmam Bayıldı'
    },
    favoriteActivities: ['Ride A Bike,', 'Reading Book,','Cooking,','To Eat,','Meeting People']
           
}
function showUser(value){

    document.querySelector(".photo").src = "IMG-20220411-WA0049.jpg";

    document.querySelector('.user-name').innerHTML += `
        : ${personalInformation.name}
    `
    document.querySelector('.user-surname').innerHTML += `
        : ${personalInformation.surname}
    `
    document.querySelector('.userInformations-town').innerHTML += `
        : ${personalInformation.location.town}
    `
    document.querySelector('.userInformations-adress').innerHTML += `
        : ${personalInformation.location.adress}
    `
    document.querySelector('.userInformations-age').innerHTML += `
        : ${personalInformation.singular.age}
    `
    document.querySelector('.userInformations-placeOfBirth').innerHTML += `
        : ${personalInformation.singular.placeOfBirth}
    `
    document.querySelector('.userInformations-favoriteFood').innerHTML += `
        : ${personalInformation.singular.favoriteFood}
    `
    let favoriteActivitiess = document.querySelector('.favoriteActivitiess')

    for (index in personalInformation.favoriteActivities) {
        favoriteActivitiess.innerHTML += `${personalInformation.favoriteActivities[index]}
        `
    }

    document.getElementById("buttonFirst").disabled = true;
}
var buttonSecond=document.querySelector("#buttonSecond");
var user=document.querySelector("#user");


buttonSecond.onclick=function(){
    
    var red=Math.floor(Math.random()*255);
    var green=Math.floor(Math.random()*255);
    var blue=Math.floor(Math.random()*255);
    
    var color=`rgb(${red} ,${green}, ${blue})`;
    user.style.background=color;
}

